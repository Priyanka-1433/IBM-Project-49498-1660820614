# ASSIGNMENT 04 
     This project is working with Docker and kubernetes and deploy in the Nodeport.  <br>

[NODEPORT APPLICATION LINK](http://169.51.203.165:32687/)